To generate the documentation, install doxygen (www.doxygen.org) and run:
	doxygen

If you have dot installed, run:
	doxygen doxifile-dot

The documentation generated with dot will have better class diagrams.